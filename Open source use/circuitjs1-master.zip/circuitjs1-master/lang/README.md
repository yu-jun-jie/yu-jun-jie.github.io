[The locale files for translation are here](../src/com/lushprojects/circuitjs1/public).

To make a new one, create a text file with lines of the form "string"="translation".  See one of the existing locale files for an example.  Use [locale_template.txt](locale_template.txt) as a template, or see [all_strings.txt](all_strings.txt) for the current list of all strings.
